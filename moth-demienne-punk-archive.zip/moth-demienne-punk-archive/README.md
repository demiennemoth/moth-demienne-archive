# Moth Demienne Archive

A black-and-white punk-gothic / psychedelic social links page. Built with plain HTML and CSS.

## Customize
- Open `index.html`.
- Replace each social link's `href="#"` with your actual profile URL.
- Replace `your@email.com` in both email links.
- The display fonts load from Google Fonts; fallback fonts are included.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` to the repository root.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then save.
5. Open the published URL shown in Pages settings.
